#pragma once
#include "RegionGeometry.hpp"
#include <linux/input.h>
#include <algorithm>
#include <cstdint>
#include <vector>

namespace ta {
struct RegionConfig {
    std::vector<Stroke> strokes;
    HitMode mode{HitMode::Both};
    float screenScaleX{1.f}, screenScaleY{1.f};
    float offsetX{0.f}, offsetY{0.f};
    float pathTolerance{18.f}, closureTolerance{18.f};
};
struct FingerState {
    int trackingId{-1};
    float rawX{0}, rawY{0};
    bool hasX{false}, hasY{false}, active{false}, inRegion{false};
};

// Tracks Linux MT Type-B contacts independently. A contact is evaluated at
// SYN_REPORT, after its slot's X/Y updates have arrived.
class MultitouchRegionTracker {
public:
    explicit MultitouchRegionTracker(size_t slots = 16) : fingers_(std::max<size_t>(1, slots)) {}
    void setRegion(const RegionConfig& cfg) { cfg_ = cfg; }
    void consume(const input_event& ev) {
        if (ev.type == EV_ABS) {
            if (ev.code == ABS_MT_SLOT) {
                currentSlot_ = std::clamp(ev.value, 0, static_cast<int>(fingers_.size()-1));
                return;
            }
            FingerState& f = fingers_[static_cast<size_t>(currentSlot_)];
            if (ev.code == ABS_MT_TRACKING_ID) {
                if (ev.value < 0) {
                    f = FingerState{};
                } else {
                    f.trackingId = ev.value;
                    f.active = true;
                    f.inRegion = false;
                }
            } else if (ev.code == ABS_MT_POSITION_X) {
                f.rawX = static_cast<float>(ev.value); f.hasX = true;
            } else if (ev.code == ABS_MT_POSITION_Y) {
                f.rawY = static_cast<float>(ev.value); f.hasY = true;
            }
        } else if (ev.type == EV_SYN && ev.code == SYN_REPORT) {
            for (auto& f : fingers_) {
                if (!f.active || !f.hasX || !f.hasY) { f.inRegion = false; continue; }
                Point p{f.rawX * cfg_.screenScaleX + cfg_.offsetX,
                        f.rawY * cfg_.screenScaleY + cfg_.offsetY};
                f.inRegion = contains(p, cfg_.strokes, cfg_.mode,
                                      cfg_.pathTolerance, cfg_.closureTolerance);
            }
        }
    }
    const std::vector<FingerState>& fingers() const { return fingers_; }
    bool anyFingerInRegion() const {
        for (const auto& f : fingers_) if (f.active && f.inRegion) return true;
        return false;
    }
private:
    std::vector<FingerState> fingers_;
    RegionConfig cfg_{};
    int currentSlot_{0};
};

// Timing policy helper. A factor >1 means slower (longer intervals), <1 faster.
// Clamp to avoid zero/overflow intervals. This does not itself schedule events.
inline int64_t scaleIntervalUs(int64_t intervalUs, float speed) {
    const float safe = std::clamp(speed, 0.1f, 10.f);
    return static_cast<int64_t>(std::clamp<double>(
        static_cast<double>(intervalUs) / safe, 0.0, 10'000'000.0));
}
} // namespace ta
