cmake_minimum_required(VERSION 3.22.1)
project(touchbridge LANGUAGES CXX)

option(TOUCHASSIST_BUILD_HOST_TESTS "Build host-only native tests" ON)

add_executable(touchbridge touchbridge.cpp)
target_compile_features(touchbridge PRIVATE cxx_std_17)
target_compile_options(touchbridge PRIVATE -Wall -Wextra -Werror=return-type)

# Android Gradle packages assets from src/main/assets. Emit the NDK-built PIE
# executable there; Gradle's ABI filter guarantees this is arm64-v8a only.
if(ANDROID)
  set(TOUCHASSIST_ASSET_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../../app/build/generated/touchbridgeAssets")
  file(MAKE_DIRECTORY "${TOUCHASSIST_ASSET_DIR}")
  set_target_properties(touchbridge PROPERTIES
    RUNTIME_OUTPUT_DIRECTORY "${TOUCHASSIST_ASSET_DIR}")
  foreach(cfg DEBUG RELEASE RELWITHDEBINFO MINSIZEREL)
    set_target_properties(touchbridge PROPERTIES
      RUNTIME_OUTPUT_DIRECTORY_${cfg} "${TOUCHASSIST_ASSET_DIR}")
  endforeach()
endif()

if(TOUCHASSIST_BUILD_HOST_TESTS AND NOT ANDROID)
  add_executable(region_geometry_test tests/region_geometry_test.cpp)
  target_compile_features(region_geometry_test PRIVATE cxx_std_17)
  target_compile_options(region_geometry_test PRIVATE -Wall -Wextra -Werror)

  add_executable(multitouch_region_engine_test tests/multitouch_region_engine_test.cpp)
  target_compile_features(multitouch_region_engine_test PRIVATE cxx_std_17)
  target_compile_options(multitouch_region_engine_test PRIVATE -Wall -Wextra -Werror)

  add_executable(region_runtime_test tests/region_runtime_test.cpp)
  target_compile_features(region_runtime_test PRIVATE cxx_std_17)
  target_compile_options(region_runtime_test PRIVATE -Wall -Wextra -Werror)
endif()
