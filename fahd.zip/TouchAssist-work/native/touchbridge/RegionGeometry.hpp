#pragma once
#include <algorithm>
#include <cmath>
#include <vector>

namespace ta {
struct Point { float x{}, y{}; };
using Stroke = std::vector<Point>;
enum class HitMode { Paths, Enclosed, Both };

inline float distance(Point a, Point b) {
    return std::hypot(a.x - b.x, a.y - b.y);
}
inline float segmentDistance(Point p, Point a, Point b) {
    const float dx=b.x-a.x, dy=b.y-a.y;
    const float len2=dx*dx+dy*dy;
    if (len2 <= 1e-6f) return distance(p,a);
    const float t=std::clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/len2,0.0f,1.0f);
    return distance(p,{a.x+t*dx,a.y+t*dy});
}
inline bool onPaths(Point p, const std::vector<Stroke>& strokes, float tolerance) {
    for (const auto& s: strokes) {
        if (s.size()==1 && distance(p,s.front())<=tolerance) return true;
        for (size_t i=1;i<s.size();++i)
            if (segmentDistance(p,s[i-1],s[i])<=tolerance) return true;
    }
    return false;
}
inline bool closedContour(const Stroke& s, float tolerance) {
    return s.size()>=4 && distance(s.front(),s.back())<=tolerance;
}
inline bool insidePolygon(Point p, const Stroke& s) {
    if (s.size()<4) return false;
    bool inside=false;
    // The last point repeats the first; omit it from the edge iteration.
    const size_t n=s.size()-1;
    size_t j=n-1;
    for (size_t i=0;i<n;++i) {
        const Point a=s[i], b=s[j];
        if (segmentDistance(p,a,b)<=0.5f) return true;
        const bool crosses=((a.y>p.y)!=(b.y>p.y)) &&
            (p.x < (b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x);
        if (crosses) inside=!inside;
        j=i;
    }
    return inside;
}
inline bool inEnclosedArea(Point p, const std::vector<Stroke>& strokes, float closureTolerance) {
    for (const auto& s: strokes)
        if (closedContour(s,closureTolerance) && insidePolygon(p,s)) return true;
    return false;
}
inline bool contains(Point p, const std::vector<Stroke>& strokes, HitMode mode,
                     float pathTolerance=18.0f, float closureTolerance=18.0f) {
    const bool path=onPaths(p,strokes,pathTolerance);
    const bool area=inEnclosedArea(p,strokes,closureTolerance);
    switch(mode) {
        case HitMode::Paths: return path;
        case HitMode::Enclosed: return area;
        case HitMode::Both: return path || area;
    }
    return false;
}
inline std::vector<Stroke> transform(const std::vector<Stroke>& strokes,
                                    float scaleX,float scaleY,float offsetX,float offsetY) {
    std::vector<Stroke> out=strokes;
    for (auto& stroke:out) for (auto& p:stroke) {
        p.x=p.x*scaleX+offsetX; p.y=p.y*scaleY+offsetY;
    }
    return out;
}
} // namespace ta
