#pragma once
#include "TouchRegionEngine.hpp"
#include <fstream>
#include <sstream>
#include <string>
#include <thread>
#include <chrono>
#include <cmath>
#include <sys/time.h>

namespace ta {
struct RuntimeSettings {
    int touchDurationMs{100}, swipeDurationMs{150}, tapDurationMs{100}, longPressDurationMs{500};
    float touchSpeed{1.f}, swipeSpeed{1.f};
};
struct RuntimeFinger {
    bool active{false}, wasInRegion{false}, moved{false};
    int trackingId{-1};
    int64_t downUs{0}, lastUs{0};
    float startX{0}, startY{0}, x{0}, y{0};
};
struct FingerClock {
    bool active{false};
    int trackingId{-1};
    int64_t rawUs{0}, adjustedUs{0}, downAdjustedUs{0};
};
struct RuntimeConfig {
    RegionConfig region;
    RuntimeSettings settings;
    bool enabled{false};
    bool floatingBall{false};
};
inline bool loadRuntimeConfig(const std::string& path, RuntimeConfig& c) {
    std::ifstream in(path); if (!in) return false;
    std::string line;
    while (std::getline(in,line)) {
        if (line.empty() || line[0]=='#') continue;
        auto p=line.find('='); if (p==std::string::npos) continue;
        std::string k=line.substr(0,p), v=line.substr(p+1); std::istringstream s(v);
        if(k=="enabled") { int x=0; s>>x; c.enabled=x!=0; }
        else if(k=="ball_mode") { int x=0; s>>x; c.floatingBall=x!=0; }
        else if(k=="mode") { if(v=="PATHS") c.region.mode=HitMode::Paths; else if(v=="ENCLOSED") c.region.mode=HitMode::Enclosed; else c.region.mode=HitMode::Both; }
        else if(k=="scale_x") s>>c.region.screenScaleX;
        else if(k=="scale_y") s>>c.region.screenScaleY;
        else if(k=="ball_x") { if(c.floatingBall) s>>c.region.offsetX; }
        else if(k=="ball_y") { if(c.floatingBall) s>>c.region.offsetY; }
        else if(k=="offset_x") s>>c.region.offsetX;
        else if(k=="offset_y") s>>c.region.offsetY;
        else if(k=="path_tolerance") s>>c.region.pathTolerance;
        else if(k=="closure_tolerance") s>>c.region.closureTolerance;
        else if(k=="touch_duration_ms") s>>c.settings.touchDurationMs;
        else if(k=="swipe_duration_ms") s>>c.settings.swipeDurationMs;
        else if(k=="tap_duration_ms") s>>c.settings.tapDurationMs;
        else if(k=="long_press_duration_ms") s>>c.settings.longPressDurationMs;
        else if(k=="touch_speed") s>>c.settings.touchSpeed;
        else if(k=="swipe_speed") s>>c.settings.swipeSpeed;
        else if(k=="stroke") {
            Stroke st; std::stringstream pts(v); std::string pair;
            while(std::getline(pts,pair,';')) { auto comma=pair.find(','); if(comma==std::string::npos) continue;
                try { st.push_back({std::stof(pair.substr(0,comma)),std::stof(pair.substr(comma+1))}); } catch(...) {} }
            if(!st.empty()) c.region.strokes.push_back(std::move(st));
        }
    }
    c.settings.touchDurationMs=std::clamp(c.settings.touchDurationMs,0,1000);
    c.settings.swipeDurationMs=std::clamp(c.settings.swipeDurationMs,0,1000);
    c.settings.tapDurationMs=std::clamp(c.settings.tapDurationMs,0,1000);
    c.settings.longPressDurationMs=std::clamp(c.settings.longPressDurationMs,0,1000);
    c.settings.touchSpeed=std::clamp(c.settings.touchSpeed,.1f,10.f);
    c.settings.swipeSpeed=std::clamp(c.settings.swipeSpeed,.1f,10.f);
    return c.enabled && !c.region.strokes.empty();
}
inline int64_t eventTimeUs(const input_event& e) { return int64_t(e.time.tv_sec)*1000000 + e.time.tv_usec; }
class RegionRuntime {
public:
    explicit RegionRuntime(RuntimeConfig cfg, size_t slots=16): cfg_(std::move(cfg)), fingers_(std::max<size_t>(1,slots)), dirty_(std::max<size_t>(1,slots),false), clocks_(std::max<size_t>(1,slots)) {}
    void replaceConfig(RuntimeConfig cfg) {
        cfg_ = std::move(cfg);
        for (auto& f : fingers_) f = RuntimeFinger{};
        for (auto& c : clocks_) c = FingerClock{};
    }
    // Updates hit-testing state at frame boundaries. No sleeps occur here.
    int64_t consume(const input_event& e) {
        if(!cfg_.enabled) return 0;
        if(e.type==EV_ABS && e.code==ABS_MT_SLOT) { slot_=std::clamp(e.value,0,(int)fingers_.size()-1); return 0; }
        auto& f=fingers_[(size_t)slot_];
        const int64_t now=eventTimeUs(e);
        int64_t delay=0;
        if(e.type==EV_ABS && e.code==ABS_MT_TRACKING_ID) {
            if(e.value<0) {
                if(f.active && f.wasInRegion) {
                    const int64_t elapsed=std::max<int64_t>(0,now-f.downUs);
                    const int specific=f.moved ? cfg_.settings.swipeDurationMs :
                        (elapsed>=500000 ? cfg_.settings.longPressDurationMs : cfg_.settings.tapDurationMs);
                    const int target=std::max(cfg_.settings.touchDurationMs,specific);
                    delay=std::max<int64_t>(0,int64_t(target)*1000-elapsed);
                }
                f=RuntimeFinger{};
            } else { f=RuntimeFinger{}; f.active=true; f.trackingId=e.value; f.downUs=now; f.lastUs=now; }
            dirty_[(size_t)slot_]=true;
        } else if(e.type==EV_ABS && e.code==ABS_MT_POSITION_X) { f.x=(float)e.value; dirty_[(size_t)slot_]=true; }
        else if(e.type==EV_ABS && e.code==ABS_MT_POSITION_Y) { f.y=(float)e.value; dirty_[(size_t)slot_]=true; }
        else if(e.type==EV_SYN && e.code==SYN_REPORT) {
            for(size_t i=0;i<fingers_.size();++i) {
                auto& contact=fingers_[i]; if(!dirty_[i]) continue; dirty_[i]=false;
                if(!contact.active) continue;
                Point p{contact.x*cfg_.region.screenScaleX+cfg_.region.offsetX,
                        contact.y*cfg_.region.screenScaleY+cfg_.region.offsetY};
                const bool hit=contains(p,cfg_.region.strokes,cfg_.region.mode,cfg_.region.pathTolerance,cfg_.region.closureTolerance);
                if(hit) {
                    if(!contact.wasInRegion) { contact.downUs=now; contact.startX=contact.x; contact.startY=contact.y; }
                    if(std::hypot(contact.x-contact.startX,contact.y-contact.startY)>8.f) contact.moved=true;
                    if(contact.wasInRegion && contact.lastUs>0 && now>contact.lastUs) {
                        const float speed=contact.moved?cfg_.settings.swipeSpeed:cfg_.settings.touchSpeed;
                        const int64_t raw=now-contact.lastUs;
                        const int64_t scaled=scaleIntervalUs(raw,speed);
                        delay=std::max(delay,std::max<int64_t>(0,scaled-raw));
                    }
                }
                contact.wasInRegion=hit; contact.lastUs=now;
            }
        }
        return std::min<int64_t>(delay,1000000);
    }
    // Retimes each contact's event clock independently. This deliberately does
    // not sleep in the input loop, so one finger cannot stall another. Linux
    // uinput preserves these per-event timestamps while event ordering stays intact.
    void retime(input_event& e) {
        if (e.type == EV_ABS && e.code == ABS_MT_SLOT) {
            slot_ = std::clamp(e.value, 0, static_cast<int>(clocks_.size()) - 1);
            return;
        }
        if (e.type == EV_SYN && e.code == SYN_REPORT) {
            const int64_t raw = eventTimeUs(e);
            if (raw > 0) setEventTime(e, std::max(raw, lastOutputUs_));
            lastOutputUs_ = std::max(lastOutputUs_, eventTimeUs(e));
            return;
        }
        if (e.type != EV_ABS) return;
        auto& c = clocks_[static_cast<size_t>(slot_)];
        const int64_t raw = eventTimeUs(e);
        if (raw <= 0) return;
        if (e.code == ABS_MT_TRACKING_ID && e.value >= 0) {
            c = FingerClock{}; c.active = true; c.trackingId = e.value;
            c.rawUs = raw; c.adjustedUs = raw; c.downAdjustedUs = raw;
            return;
        }
        if (!c.active) return;
        const bool inside = fingers_[static_cast<size_t>(slot_)].wasInRegion;
        if (raw > c.rawUs) {
            const float speed = fingers_[static_cast<size_t>(slot_)].moved ? cfg_.settings.swipeSpeed : cfg_.settings.touchSpeed;
            const int64_t delta = raw - c.rawUs;
            c.adjustedUs += inside ? scaleIntervalUs(delta, speed) : delta;
            c.rawUs = raw;
        }
        if (e.code == ABS_MT_TRACKING_ID && e.value < 0 && inside) {
            const int64_t elapsedRaw = raw - fingers_[static_cast<size_t>(slot_)].downUs;
            const int specific = fingers_[static_cast<size_t>(slot_)].moved ? cfg_.settings.swipeDurationMs :
                (elapsedRaw >= 500000 ? cfg_.settings.longPressDurationMs : cfg_.settings.tapDurationMs);
            const int target = std::max(cfg_.settings.touchDurationMs, specific);
            c.adjustedUs = std::max(c.adjustedUs, c.downAdjustedUs + int64_t(target) * 1000);
        }
        int64_t out = std::max(c.adjustedUs, lastOutputUs_);
        setEventTime(e, out); lastOutputUs_ = out;
        if (e.code == ABS_MT_TRACKING_ID && e.value < 0) c = FingerClock{};
    }
private:
    static void setEventTime(input_event& e, int64_t us) {
        e.time.tv_sec = static_cast<decltype(e.time.tv_sec)>(us / 1000000);
        e.time.tv_usec = static_cast<decltype(e.time.tv_usec)>(us % 1000000);
    }
    RuntimeConfig cfg_; std::vector<RuntimeFinger> fingers_; std::vector<bool> dirty_; std::vector<FingerClock> clocks_; int slot_{0}; int64_t lastOutputUs_{0};
};
inline void waitForRegionDelay(int64_t us) {
    if(us>0) std::this_thread::sleep_for(std::chrono::microseconds(us));
}
} // namespace ta
