#include "../RegionRuntime.hpp"
#include <cassert>
#include <cstdio>
int main(){
    ta::RuntimeConfig c; c.enabled=true; c.region.mode=ta::HitMode::Enclosed;
    c.region.strokes={{{0,0},{100,0},{100,100},{0,100},{0,0}}};
    c.settings.touchDurationMs=80; c.settings.tapDurationMs=120; c.settings.touchSpeed=2.f;
    ta::RegionRuntime rt(c,2);
    auto ev=[](unsigned short type,unsigned short code,int value,long sec,long usec){ input_event e{}; e.type=type;e.code=code;e.value=value;e.time.tv_sec=sec;e.time.tv_usec=usec;return e; };
    rt.consume(ev(EV_ABS,ABS_MT_SLOT,0,1,0));
    rt.consume(ev(EV_ABS,ABS_MT_TRACKING_ID,7,1,0));
    rt.consume(ev(EV_ABS,ABS_MT_POSITION_X,50,1,0));
    rt.consume(ev(EV_ABS,ABS_MT_POSITION_Y,50,1,0));
    rt.consume(ev(EV_SYN,SYN_REPORT,0,1,1000));
    // Second contact is tracked independently in slot 1.
    rt.consume(ev(EV_ABS,ABS_MT_SLOT,1,1,1000));
    rt.consume(ev(EV_ABS,ABS_MT_TRACKING_ID,8,1,1000));
    rt.consume(ev(EV_ABS,ABS_MT_POSITION_X,150,1,1000));
    rt.consume(ev(EV_ABS,ABS_MT_POSITION_Y,150,1,1000));
    rt.consume(ev(EV_SYN,SYN_REPORT,0,1,2000));
    // Slot 0 movement inside the polygon is sped up (shorter interval).
    rt.consume(ev(EV_ABS,ABS_MT_SLOT,0,1,2000));
    rt.consume(ev(EV_ABS,ABS_MT_POSITION_X,60,1,2000));
    rt.consume(ev(EV_SYN,SYN_REPORT,0,1,12000));
    // End contact: tap duration floor is returned as a delay.
    rt.consume(ev(EV_ABS,ABS_MT_SLOT,0,1,12000));
    auto delay=rt.consume(ev(EV_ABS,ABS_MT_TRACKING_ID,-1,1,12000));
    assert(delay>=0 && delay<=1000000);

    // Verify per-slot timestamp retiming without sleeping the event loop.
    ta::RuntimeConfig timed; timed.enabled=true; timed.region.mode=ta::HitMode::Enclosed;
    timed.region.strokes={{{0,0},{100,0},{100,100},{0,100},{0,0}}};
    timed.settings.touchSpeed=2.f; timed.settings.swipeSpeed=2.f;
    timed.settings.touchDurationMs=0; timed.settings.tapDurationMs=0; timed.settings.longPressDurationMs=0;
    ta::RegionRuntime clocked(timed,2);
    auto feed=[&](input_event e){ clocked.consume(e); clocked.retime(e); return e; };
    feed(ev(EV_ABS,ABS_MT_SLOT,0,2,0));
    feed(ev(EV_ABS,ABS_MT_TRACKING_ID,11,2,0));
    feed(ev(EV_ABS,ABS_MT_POSITION_X,50,2,0));
    feed(ev(EV_ABS,ABS_MT_POSITION_Y,50,2,0));
    feed(ev(EV_SYN,SYN_REPORT,0,2,0));
    auto sped = feed(ev(EV_ABS,ABS_MT_POSITION_X,55,2,100000));
    assert(sped.time.tv_sec==2 && sped.time.tv_usec==50000);
    // A second slot starts independently; no sleep or shared delay queue exists.
    feed(ev(EV_ABS,ABS_MT_SLOT,1,2,100000));
    auto secondDown = feed(ev(EV_ABS,ABS_MT_TRACKING_ID,12,2,100000));
    assert(secondDown.time.tv_sec==2 && secondDown.time.tv_usec>=100000);
    std::puts("region runtime tests passed");
}
