# Region geometry host tests

Run `sh native/touchbridge/tests/run-host-tests.sh` on a host with g++.
These tests cover geometry only. They do not open input devices, grab the
physical touchscreen, synthesize input, or validate Android InputReader.
