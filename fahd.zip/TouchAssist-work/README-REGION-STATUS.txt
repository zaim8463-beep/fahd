TouchAssist Region Runtime - integration status

Implemented in this source update:
- Android exports the selected TouchRegion to app-private files/region.conf.
- Region activation exports the selected hit mode, region settings, screen scale,
  and either the pinned ball translation or zero translation for no-ball mode.
- Initial ball placement persists the translation to the region config.
- Root launcher accepts an optional region.conf path.
- Native bridge polls the config and reloads a valid replacement while running.
- Native bridge no longer sleeps on a computed delay in its event loop. It retimes
  event timestamps per multitouch slot, preserving event ordering and avoiding a
  blocking sleep that stalls all fingers.

Still not certified / not complete:
- The Android service does not automatically launch and supervise the root bridge.
  The root launcher must currently be started separately with the app PID and
  app-private config path.
- The pinned region ball is placed and its offset exported at placement time;
  dragging an already-pinned ball to a new position is not implemented as a
  dedicated move gesture yet.
- Per-slot timestamp retiming is not equivalent to independent wall-clock
  scheduling: Linux input events share one ordered stream and a monotonic output
  timeline. Some cross-slot timing interactions remain possible.
- The native engine has not been run against the physical touchscreen or uinput
  device on the target handset. Do not enable EVIOCGRAB until tested with a
  reliable external recovery path.
- Android APK build and device test are not available in this environment.

Host verification:
- CMake native build: required to pass before packaging.
- Host region geometry, multitouch and runtime tests: required to pass.
