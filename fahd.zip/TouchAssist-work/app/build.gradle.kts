plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.touchassist"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.touchassist"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // The supplied handset is ARM64. Do not package an incompatible host binary.
        ndk { abiFilters += "arm64-v8a" }
        externalNativeBuild {
            cmake { arguments += listOf("-DANDROID_STL=c++_static", "-DTOUCHASSIST_BUILD_HOST_TESTS=OFF") }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("../native/touchbridge/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    sourceSets {
        getByName("main").assets.srcDir(layout.buildDirectory.dir("generated/touchbridgeAssets"))
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Ensure the NDK executable exists before Android merges app assets.
tasks.configureEach {
    if (name.startsWith("merge") && name.endsWith("Assets")) {
        val variant = name.removePrefix("merge").removeSuffix("Assets")
        dependsOn("externalNativeBuild$variant")
    }
}
