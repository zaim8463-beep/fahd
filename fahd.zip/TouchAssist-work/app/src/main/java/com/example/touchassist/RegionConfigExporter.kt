package com.example.touchassist

import android.content.Context
import java.io.File

/** Writes the selected region in the simple key/value format consumed by touchbridge.
 * The file lives in app-private storage; a root-launched bridge can read it directly.
 */
object RegionConfigExporter {
    @Synchronized
    fun export(context: Context, region: TouchRegion, offsetX: Float = 0f, offsetY: Float = 0f) {
        val g = region.gesture
        val s = region.settings
        s.normalize()
        val lines = ArrayList<String>()
        lines += "enabled=1"
        lines += "ball_mode=${if (region.floatingBall) 1 else 0}"
        lines += "mode=${region.hitMode.name}"
        lines += "offset_x=$offsetX"
        lines += "offset_y=$offsetY"
        // Device touchscreen ABS ranges confirmed for the target handset: X 0..2879, Y 0..6415.
        lines += "scale_x=${g.screenW.toFloat() / 2879f}"
        lines += "scale_y=${g.screenH.toFloat() / 6415f}"
        lines += "touch_duration_ms=${s.touchDurationMs}"
        lines += "touch_speed=${s.touchSpeed}"
        lines += "swipe_duration_ms=${s.swipeDurationMs}"
        lines += "swipe_speed=${s.swipeSpeed}"
        lines += "tap_duration_ms=${s.tapDurationMs}"
        lines += "long_press_duration_ms=${s.longPressDurationMs}"
        for (stroke in g.strokes) {
            val points = stroke.points.joinToString(";") { "${it.x},${it.y}" }
            if (points.isNotBlank()) lines += "stroke=$points"
        }
        val target = File(context.filesDir, "region.conf")
        val temp = File(context.filesDir, "region.conf.tmp")
        temp.writeText(lines.joinToString("\n") + "\n")
        if (target.exists() && !target.delete()) throw IllegalStateException("Cannot replace region.conf")
        if (!temp.renameTo(target)) throw IllegalStateException("Cannot publish region.conf")
    }

    fun configPath(context: Context): String = File(context.filesDir, "region.conf").absolutePath
}
