TouchAssist region hit-mode update

The region editor now saves one of three explicit choices:
- PATHS: touches on/near recorded strokes
- ENCLOSED: touches inside the closed area described by the strokes
- BOTH: either condition

The selected mode is persisted as `hitMode` in `touch_regions_v1`; older saved regions
without this key load as BOTH. This is a data-model/UI feature only in this source snapshot.

IMPORTANT: the native touchbridge remains a raw passthrough prototype. It does not yet
load this JSON, convert display coordinates to the device ABS range, classify multitouch
contacts against paths/polygons, or apply per-region timing/speed transformations.
The Android app does not yet supervise/launch the native process. Do not enable EVIOCGRAB
on the daily-use touchscreen with this build. No APK is provided or claimed.
